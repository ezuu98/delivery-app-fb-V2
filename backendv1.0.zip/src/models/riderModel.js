const { getFirestore } = require('../services/firestore');

function daysSince(iso){
  const t = Date.parse(iso || '');
  if (!Number.isFinite(t)) return 9999;
  const diff = Date.now() - t;
  return Math.max(0, Math.floor(diff / 86400000));
}

function mapRider(doc){
  const d = doc && doc.data ? doc.data() : (doc || {});
  const id = String((doc && doc.id) || d.uid || '');
  const name = d.displayName || d.name || d.email || 'Unknown';
  const totalKm = Number(d.totalKm || 0);
  const performance = Number(d.performance || 80);
  const commissionUsd = Number(d.commissionUsd || 0);
  const lastActiveDays = daysSince(d.updatedAt || d.createdAt || null);
  const status = lastActiveDays <= 30 ? 'Active' : 'Inactive';
  return { id, name, totalKm, performance, commissionUsd, status, lastActiveDays };
}

async function list() {
  const db = getFirestore();
  if (!db) return [];
  const snap = await db.collection('riders').get();
  const res = [];
  snap.forEach(doc => { res.push(mapRider(doc)); });
  return res;
}

async function getById(id) {
  const db = getFirestore();
  if (!db) return null;
  const ref = db.collection('riders').doc(String(id));
  const snap = await ref.get();
  if (!snap.exists) return null;
  return mapRider(snap);
}

module.exports = { list, getById };
